import sys
import shutil
import os

# destination folder for the AWS exporting
Location = '/XMLFileCopy'

if not os.path.exists(Location):
    os.makedirs(Location)

for file in os.listdir("./"):
    if file.endswith(".xml") and file.startswith("event"):
        shutil.copy(os.path.join("./", file), Location)
        os.remove(os.path.join("./", file))